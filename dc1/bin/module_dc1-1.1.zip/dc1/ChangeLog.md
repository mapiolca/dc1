# DC1 ChangeLog

## 1.1.0 (03/09/2025)

- Ajout de la version 2019 du formulaire DC1

1.1.0.0 (30/09/2025)

- Création du module dédié aux Formulaires DC1
